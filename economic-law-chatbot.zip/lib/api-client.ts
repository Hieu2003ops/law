// This file contains functions to interact with your backend API

export interface Message {
  id: number | string
  role: "user" | "assistant"
  content: string
  source?: "rag" | "model"
  model?: "llama" | "gemini"
  timestamp?: number
}

export interface ApiResponse {
  ragResponse: Message
  llamaResponse: Message
  geminiResponse: Message
}

// Replace the entire sendMessage function with this updated version
export async function sendMessage(message: string): Promise<ApiResponse> {
  try {
    // Use our internal Next.js API routes instead of external endpoints
    const [ragResponse, llamaResponse, geminiResponse] = await Promise.all([
      fetch("/api/chat-rag", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messages: [{ role: "user", content: message }],
        }),
      }),
      fetch("/api/chat-llama", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messages: [{ role: "user", content: message }],
        }),
      }),
      fetch("/api/chat-gemini", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messages: [{ role: "user", content: message }],
        }),
      }),
    ])

    // Check if any of the responses failed
    if (!ragResponse.ok || !llamaResponse.ok || !geminiResponse.ok) {
      throw new Error("One or more API requests failed")
    }

    // Process the streaming responses
    const ragReader = ragResponse.body?.getReader()
    const llamaReader = llamaResponse.body?.getReader()
    const geminiReader = geminiResponse.body?.getReader()

    // For simplicity, we'll just get the full text from each stream
    // In a production app, you might want to handle streaming more elegantly
    const ragText = await readStreamToCompletion(ragReader)
    const llamaText = await readStreamToCompletion(llamaReader)
    const geminiText = await readStreamToCompletion(geminiReader)

    const timestamp = Date.now()

    // Format the responses into the expected structure
    return {
      ragResponse: {
        id: `rag-${timestamp}`,
        role: "assistant",
        content: ragText || "Không thể kết nối đến máy chủ RAG. Vui lòng thử lại sau.",
        source: "rag",
        timestamp,
      },
      llamaResponse: {
        id: `llama-${timestamp}`,
        role: "assistant",
        content: llamaText || "Không thể kết nối đến máy chủ Meta Llama. Vui lòng thử lại sau.",
        source: "model",
        model: "llama",
        timestamp,
      },
      geminiResponse: {
        id: `gemini-${timestamp}`,
        role: "assistant",
        content: geminiText || "Không thể kết nối đến máy chủ Gemini. Vui lòng thử lại sau.",
        source: "model",
        model: "gemini",
        timestamp,
      },
    }
  } catch (error) {
    console.error("Error sending message:", error)

    // Return mock responses in case of error (for development)
    const timestamp = Date.now()
    return {
      ragResponse: {
        id: `rag-${timestamp}`,
        role: "assistant",
        content: "Không thể kết nối đến máy chủ RAG. Vui lòng thử lại sau.",
        source: "rag",
        timestamp,
      },
      llamaResponse: {
        id: `llama-${timestamp}`,
        role: "assistant",
        content: "Không thể kết nối đến máy chủ Meta Llama. Vui lòng thử lại sau.",
        source: "model",
        model: "llama",
        timestamp,
      },
      geminiResponse: {
        id: `gemini-${timestamp}`,
        role: "assistant",
        content: "Không thể kết nối đến máy chủ Gemini. Vui lòng thử lại sau.",
        source: "model",
        model: "gemini",
        timestamp,
      },
    }
  }
}

// Add this helper function to read streaming responses
async function readStreamToCompletion(reader?: ReadableStreamDefaultReader<Uint8Array>): Promise<string> {
  if (!reader) return ""

  const decoder = new TextDecoder()
  let result = ""

  try {
    while (true) {
      const { done, value } = await reader.read()
      if (done) break

      // Decode the chunk and add it to our result
      const chunk = decoder.decode(value, { stream: true })

      // Parse the chunk as JSON if it's in the expected format
      try {
        // AI SDK streams data in the format: data: {"text":"content"}
        const lines = chunk.split("\n")
        for (const line of lines) {
          if (line.startsWith("data:")) {
            const jsonStr = line.slice(5).trim()
            if (jsonStr) {
              const data = JSON.parse(jsonStr)
              if (data.text) {
                result += data.text
              }
            }
          }
        }
      } catch (e) {
        // If parsing fails, just append the raw chunk
        result += chunk
      }
    }
  } catch (error) {
    console.error("Error reading stream:", error)
  } finally {
    reader.releaseLock()
  }

  return result
}
