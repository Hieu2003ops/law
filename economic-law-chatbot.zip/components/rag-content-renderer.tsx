"use client"

import { useTheme } from "next-themes"

interface RagContentRendererProps {
  content: string
}

export function RagContentRenderer({ content }: RagContentRendererProps) {
  const { theme } = useTheme()
  const isDark = theme === "dark"

  // Xử lý nội dung RAG
  const processRagContent = (text: string) => {
    // Xử lý các phần đặc biệt trong nội dung RAG
    let processed = text

    // Xử lý tiêu đề và phần đánh dấu
    processed = processed.replace(
      /Theo Luật (.*?)(?:,|\n|$)/i,
      `<div class="font-semibold ${isDark ? "text-yellow-400" : "text-red-700"} mb-2">Theo Luật $1:</div>`,
    )

    // Xử lý các điều khoản
    processed = processed.replace(
      /Điều (\d+)[,.]?\s*(.*?)(?=Điều \d+|$)/gs,
      `<div class="mb-4">
        <div class="font-medium ${isDark ? "text-yellow-300" : "text-red-600"} mb-1">Điều $1:</div>
        <div class="${isDark ? "text-gray-300" : "text-gray-800"}">$2</div>
      </div>`,
    )

    // Xử lý các mục
    processed = processed.replace(
      /(\d+)\.\s*(.*?)(?=\d+\.\s|$)/gs,
      `<div class="ml-4 mb-2">
        <span class="font-medium ${isDark ? "text-yellow-200" : "text-red-500"}">$1.</span>
        <span class="${isDark ? "text-gray-300" : "text-gray-800"}"> $2</span>
      </div>`,
    )

    // Xử lý các điểm a), b), c)
    processed = processed.replace(
      /([a-z])\)\s*(.*?)(?=[a-z]\)|$)/gs,
      `<div class="ml-8 mb-1">
        <span class="font-medium ${isDark ? "text-yellow-200" : "text-red-500"}">$1)</span>
        <span class="${isDark ? "text-gray-300" : "text-gray-800"}"> $2</span>
      </div>`,
    )

    return processed
  }

  const processedContent = processRagContent(content)

  return <div className="prose max-w-none dark:prose-invert" dangerouslySetInnerHTML={{ __html: processedContent }} />
}
