"use client"
import { cn } from "@/lib/utils"
import { useTheme } from "next-themes"
import { SearchToolsFormatter } from "./search-tools-formatter"

interface MarkdownRendererProps {
  content: string
  className?: string
}

export function MarkdownRenderer({ content, className }: MarkdownRendererProps) {
  const { theme } = useTheme()
  const isDark = theme === "dark"

  // Kiểm tra xem nội dung có chứa kết quả tìm kiếm từ công cụ không
  const hasSearchResults = content.includes("--- Tavily ---") || content.includes("--- Google Serper")

  // Nếu có kết quả tìm kiếm, sử dụng SearchToolsFormatter
  if (hasSearchResults) {
    return <SearchToolsFormatter content={content} />
  }

  // Xử lý nội dung RAG
  const processRagContent = (text: string) => {
    // Kiểm tra xem có phải nội dung RAG không
    const isRagContent = text.includes("Theo luật") || text.includes("Điều") || text.includes("bảo hiểm tiền gửi")

    if (isRagContent) {
      // Xử lý tiêu đề và phần đánh dấu
      let processed = text.replace(
        /Theo luật (.*?)(?:,|\n|$)/i,
        `<div class="font-semibold ${isDark ? "text-yellow-400" : "text-red-700"} mb-2">Theo luật $1:</div>`,
      )

      // Xử lý các điều khoản
      processed = processed.replace(
        /Điều (\d+)[,.]?\s*(.*?)(?=Điều \d+|$)/gs,
        `<div class="mb-4">
          <div class="font-medium ${isDark ? "text-yellow-300" : "text-red-600"} mb-1">Điều $1:</div>
          <div class="${isDark ? "text-gray-300" : "text-gray-800"}">$2</div>
        </div>`,
      )

      // Xử lý các mục
      processed = processed.replace(
        /(\d+)\.\s*(.*?)(?=\d+\.\s|$)/gs,
        `<div class="ml-4 mb-2">
          <span class="font-medium ${isDark ? "text-yellow-200" : "text-red-500"}">$1.</span>
          <span class="${isDark ? "text-gray-300" : "text-gray-800"}"> $2</span>
        </div>`,
      )

      // Xử lý các điểm a), b), c)
      processed = processed.replace(
        /([a-z])\)\s*(.*?)(?=[a-z]\)|$)/gs,
        `<div class="ml-8 mb-1">
          <span class="font-medium ${isDark ? "text-yellow-200" : "text-red-500"}">$1)</span>
          <span class="${isDark ? "text-gray-300" : "text-gray-800"}"> $2</span>
        </div>`,
      )

      return processed
    }

    // Process the content to handle markdown-like formatting
    let processed = text.replace(
      /Pipeline result: ==============================/g,
      `<div class="${
        isDark ? "text-gray-400 border-gray-600" : "text-gray-600 border-gray-300"
      } border-b pb-2 mb-4">Pipeline result: ==============================</div>`,
    )

    // Handle the PHẦN I header with proper formatting
    processed = processed.replace(
      /🎯\s*\*\*(PHẦN I: Phân tích từ văn bản pháp luật (?:$$RAG pipeline$$|$$RAG pipeline$$):)\*\*/g,
      `<div class="${
        isDark ? "text-yellow-400" : "text-red-700"
      } font-bold text-xl my-4 flex items-center"><span class="mr-2">🎯</span>$1</div>`,
    )

    // Handle bold questions
    processed = processed.replace(
      /\*\*(.*?)\*\*/g,
      `<div class="font-bold ${isDark ? "text-yellow-400" : "text-red-700"} my-2">$1</div>`,
    )

    // Handle section headers like "Trích dẫn:", "Phân tích & ví dụ minh họa:", etc.
    processed = processed.replace(
      /\*\*(Trích dẫn:|Phân tích & ví dụ minh họa:|Góc nhìn đối lập:|Tổng hợp kết luận:)\*\*/g,
      `<div class="${
        isDark ? "text-yellow-400 border-yellow-500" : "text-red-700 border-red-600"
      } font-bold mt-4 mb-2 border-l-4 pl-3 py-1">$1</div>`,
    )

    // Replace source types with proper translations
    processed = processed.replace(/🔗\s*\*\*Loại nguồn:\*\*\s*`(.*?)`/g, (match, sourceType) => {
      // Translate the source type
      let translatedType = sourceType
      let badgeColor = ""

      if (sourceType.toLowerCase() === "official") {
        translatedType = "Thông Tin Chính Phủ"
        badgeColor = isDark ? "bg-yellow-900 text-yellow-300" : "bg-red-100 text-red-800"
      } else if (sourceType.toLowerCase() === "news") {
        translatedType = "Tin Tức Liên Quan"
        badgeColor = isDark ? "bg-green-900 text-green-300" : "bg-green-100 text-green-800"
      }

      return `<div class="flex items-center gap-2 text-sm my-3">
                <span class="${isDark ? "text-yellow-400" : "text-red-600"}">🔗</span>
                <span class="font-semibold ${isDark ? "text-gray-300" : "text-gray-700"}">Loại nguồn:</span> 
                <span class="px-2.5 py-1 rounded-full text-xs font-medium ${badgeColor}">${translatedType}</span>
              </div>`
    })

    // Handle horizontal dividers
    processed = processed.replace(
      /==============================/g,
      `<hr class="my-4 border-t ${isDark ? "border-gray-600" : "border-gray-300"}" />`,
    )

    // Handle paragraphs with proper spacing
    processed = processed.replace(/\n\n/g, `</p><p class="my-3 ${isDark ? "text-gray-200" : "text-gray-800"}">`)

    // Wrap the content in paragraph tags if not already
    if (!processed.startsWith("<div") && !processed.startsWith("<p")) {
      processed = `<p class="${isDark ? "text-gray-200" : "text-gray-800"}">` + processed + "</p>"
    }

    return processed
  }

  const processedContent = processRagContent(content)

  return (
    <div
      className={cn("prose max-w-none", isDark ? "prose-invert" : "prose-gray", className)}
      dangerouslySetInnerHTML={{ __html: processedContent }}
    />
  )
}
